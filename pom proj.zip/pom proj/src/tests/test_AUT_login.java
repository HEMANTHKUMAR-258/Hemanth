package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.AUT_home_page;
import pages.AUT_login_page;

public class test_AUT_login {
	WebDriver dr;
	AUT_login_page loginpage;
	AUT_home_page  homepage;
	@BeforeClass
	public void launchbrowser(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
	}
  @Test(priority=0)
  public void test_login_page() {
	  loginpage=new AUT_login_page(dr);
	  String login_page_title=loginpage.get_title();
	  Assert.assertTrue(login_page_title.contains("Shop"));
	  
  }
  @Test(priority=1)
  public void test_home_page(){
	  loginpage.login("tirumalashetty.harika@gmail.com","anjaneya9$");
	  homepage =new AUT_home_page(dr);
	  String actual_eid=homepage.get_displayed_eid();
	  Assert.assertTrue(actual_eid.contains("tirumalashetty.harika@gmail.com"));
	  
  }
}
