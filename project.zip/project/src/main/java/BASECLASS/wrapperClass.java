package BASECLASS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class wrapperClass {
	WebDriver dr;
	int counter=1;
	public wrapperClass() {
		this.dr=dr;
	}
public void launch_browser() {
	System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	dr=new ChromeDriver();
	dr.get("https://www.demoblaze.com/index.html");
	dr.manage().window().maximize();
	dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	
	
}
public WebElement WE(By locator,int timeout) {
	
	WebElement u=null;
	try {
		WebDriverWait Wait=new WebDriverWait(dr,timeout);
		u=Wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		System.out.println("Element Found");
		}
	catch(Exception e)
	{
		System.out.println("Element not Found" +e);
	}
	return u;
}

public WebElement ETBC(By locator,int timeout)
{
	try {
		WebDriverWait wait=new WebDriverWait(dr,timeout);
		WebElement w= wait.until(ExpectedConditions.elementToBeClickable(locator));
		System.out.println("Element Found");
	}
	catch(Exception e1) {
		System.out.println("Element Not Found" +e1);
	}
	return null;
}
	
}
