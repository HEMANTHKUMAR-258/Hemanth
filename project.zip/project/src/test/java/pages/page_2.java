package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASECLASS.wrapperClass;

public class page_2 {
 
	private static final By lo = null;
	WebDriver dr;
	wrapperClass wc;
	public page_2() {
		  By lo =By.xpath("//div[@id='navbarExample']//following::li[5]//a[1]");//login click
		  By lusr=By.xpath("//input[@id='loginusername']");
		  By l_pwd=By.xpath("//input[@id='loginpassword']");
		  By l_btn=By.xpath("//body[@class='modal-open']/div[3]/div[1]/div/div[3]/button[2]");

	}
	public void login() {
		WebElement e=wc.ETBC(lo,20);
		e.click();
	}	
	public void user(String user) {
		WebElement e1=wc.WE(lusr,20);
		e1.sendKeys(user);
	}
	public void pwdd() {
		WebElement e2=wc.WE(l_pwd,20);
		e2.sendKeys(pwdd);
		
	}
	

		
	}
}
