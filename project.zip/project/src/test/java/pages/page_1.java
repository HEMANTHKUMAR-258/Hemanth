package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASECLASS.wrapperClass;

public class page_1 {
	WebDriver dr;
	wrapperClass wc;
	public page_1() {
		this.dr=dr;
		wc=new wrapperClass();
	}

	By Su =By.xpath("//a[@id='signin2']");
	By us =By.xpath("//input[@id='sign-username']");//username
	By pw =By.xpath("//input[@id='sign-password']");//password
    By cl =By.xpath("//div[@class='modal-footer']//child::button[2]");//click button
    
    public void Signup() {
    	WebElement e=wc.ETBC(Su,20);
    	e.click();
    }
    public void username(String user) {
    	WebElement e1=wc.WE(us,20);
    	e1.sendKeys(user);
    }
    public void password(String pwd) {
    	WebElement e2=wc.WE(pw, 20);
    	e2.sendKeys(pwd);
    }
    
    public void click() {
    	WebElement e3=wc.ETBC(cl, 20);
    	e3.click();
    }
    public void signingup(String u,String p) {
    	this.Signup();
    	this.username(u);
    	this.password(p);
    	this.click();
    	
    	
    }
}
