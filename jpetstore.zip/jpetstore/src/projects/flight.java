package projects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class flight {
	
	WebDriver dr;
	public void php_travels() {
		
		dr.findElement(By.xpath("//a[@id='dropdownCurrency']")).click();//changing 
		dr.findElement(By.xpath("//div[@class='dropdown-menu-inner']//a[4]")).click();
		dr.findElement(By.xpath("//button[@class='btn btn-toggle collapsed']")).click();
		dr.findElement(By.xpath("//div[@id='mobileMenuMain']//a[1]")).click();
		dr.findElement(By.xpath("//ul[@class='nav row-reverse ']//li[2]")).click();//selecitng flights
		dr.findElement(By.xpath("//div[@id='s2id_location_from']")).sendKeys("LAX");//from
		dr.findElement(By.xpath("//div[@class='select2-result-label'][1]")).click();
		dr.findElement(By.xpath("//div[@id='s2id_location_to']")).sendKeys("DFW");
		dr.findElement(By.xpath("))"
				Assert.assertTrue(condition);
	}

}
