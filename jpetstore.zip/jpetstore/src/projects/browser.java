package projects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class browser {
	
	public void launch_browser() {
		WebDriver dr;
		
		System.setProperty("webdriver.chrome.driver","chromedriver.exe" );
		dr=new ChromeDriver();
		dr.get("https://www.royalcaribbean.com/alasaka-cruises");
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

}
