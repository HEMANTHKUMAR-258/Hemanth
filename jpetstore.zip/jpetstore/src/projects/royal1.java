package projects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class royal1 {

	WebDriver dr;
	
	public String search() {
		String a=dr.findElement(By.xpath("//div[@id='textWithUI-262899300']//a")).getText();
		
		dr.findElement(By.xpath("//*[@id='rciHeaderOpenSidenav']")).click();//button
		dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		dr.findElement(By.xpath("//*[@id='rciHeaderSideNavMenu-1']")).click();//plain a cruise
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		dr.findElement(By.xpath("//*[@id='rciHeaderSideNavSubmenu-1-1']")).click();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		dr.findElement(By.xpath("//*[id='rciHeaderMenuItem-2']")).click();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		WebDriverWait we1=new WebDriverWait(dr,20);
		WebElement e=we1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='rciSearchHeaderIcon']")));
		e.click();
		
		dr.findElement(By.xpath("//*[@id='rciSearchHeaderIcon']")).sendKeys("RHAPSODY OF THE SEAS");
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		dr.findElement(By.xpath("//div[@class='searchResult__base'][3]")).click();
		
		WebElement w=dr.findElement(By.id("deckDropdown"));
		Select se=new Select(w);
		se.selectByVisibleText("Deck Eight");
		
		
	boolean b=	dr.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[1]/div/div/div[2]/section/section[2]/section[1]/div[2]/section[5]/h4")).isDisplayed();
		
		return a;
	
		
	}
}
