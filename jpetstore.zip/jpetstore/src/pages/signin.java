package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.ExplicitCode;

public class signin {
	

	     
	     By user =By.xpath("//input[@name='username']");
	     By password=By.xpath("//input[@name='password']");
	     By login1=By.xpath("//input[@id='login']");
		WebDriver dr;
		ExplicitCode  wt;
		public  signin(WebDriver dr) {
			this.dr=dr;
			wt=new ExplicitCode (dr);
		}

		
		public void use(String us) {
			WebElement we_user=wt.waitelement(user, 20);
			we_user.sendKeys(us);
	}
		public void pass(String pwd) {
			WebElement we_password=wt.waitelement(password, 20);
			we_password.sendKeys(pwd);
	}
		public void login1() {
			WebElement we_login=wt.waitelement(login1, 20);
			we_login.click();
	}
		public String verify() {
			String  s1=dr.findElement(By.xpath("//div[@id='WelcomeContent']")).getText();
			return s1;
		}
	  public void login(String us,String pwd) {
		  
		  this.use(us);
		  this.pass(pwd);
		  this.login1();
		  wt.getscreenshot();
	  }

}
