package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import library.ExplicitCode;
import pages.class1;
import pages.signin;


public class pet_app {
		WebDriver dr;
		ExplicitCode ec= new ExplicitCode(dr);
       	signin si;
		class1 c1;
		@BeforeClass
		public void beforeClass()
		  {
			this.dr= dr= ec.launch_browser("CHROME", "https://jpetstore.cfapps.io/catalog");
			
			 si=new signin(dr);
			 c1=new class1(dr);
		  }
		 @Test(priority=0)
		  public void f() {
			 c1.call();
			 String aR=dr.getTitle();
			  Assert.assertTrue(aR.contains("JPetStore Demo"));
		  }
	 
	  @Test(priority=1)
	  public void f1() {
		  si.login("d3825104" ,"hemanth106");
		  String aR=dr.getTitle();
		  Assert.assertTrue(aR.contains("JPetStore Demo"));
		  
		  
		  
		  
		  
	  }
	  @AfterClass
	  public void afterClass()
	  {
		  dr.close();
	  }
	  
}
