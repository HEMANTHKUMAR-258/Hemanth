package tests;

import org.testng.annotations.Test;

import projects.browser;

import projects.royal1;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class Royal {
	WebDriver dr;
	browser br;
	royal1 ro;
 
  @BeforeClass
  public void beforeClass() {
	  
	  br=new browser();
	  br.launch_browser();
  }
  @Test
  public void f() {
	  ro=new royal1();
	  ro.search();
	  
  }
//  @AfterClass
//  public void afterClass() {
//	  dr.close();
//  }

}
