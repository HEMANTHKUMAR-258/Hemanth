package tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import EXCEl_UTIL.registration1;
import pages.signin;

public class NewTest1 extends registration1 {
	
	signin si;
	WebDriver dr ;
	
	 @BeforeClass
	  public void beforeclass() {
	 
	 getexcel();
	  }

	 @Test(dataProvider="register")
	 public void dp(String us,String pwd,String excep) {
		 System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 dr=new ChromeDriver();
		 dr.get("https://jpetstore.cfapps.io/login");
		 dr.manage().window().maximize();
		 System.out.println("user name" +us + "password" + pwd);
		 si=new signin(dr);
		 si.login(us,pwd);
		 String s1=si.verify();
		 System.out.println(s1);
		 System.out.println(excep);
		 Assert.assertEquals(s1, excep);
		 }
	 @DataProvider(name="register")
	 public String[][] register(){
		String[][] s=new String[2][2];
		s=getexcel();
		 return s;
	 }
	 @AfterClass
	 public void ac() {
		 dr.close();
	 }

}
	 
//	  @Test(dataProvider = "dp")
//	  public void calllogin(String FirstName,String LastName,String Email,String Password ,String cp,String E_Results) throws IOException {
//	 
//	 
//	 String A_Results=DemoRegister(FirstName,LastName,Email,Password,cp);
//	 SoftAssert sa=new SoftAssert();
//	 sa.assertEquals(E_Results, A_Results);
//	 sa.assertAll() ;
//	 
//	  }
//
//
//	  @DataProvider(name ="dp")
//	  public String[][] dp() {
//	 
//	 return testdata;
//	   
//	    };
//}
//}
