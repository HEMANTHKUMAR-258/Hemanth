package library;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitCode {
	WebDriver dr;
	static int counter=1;
	public ExplicitCode (WebDriver dr)
	{
		this.dr=dr;
	}
	public WebElement waitelement(By Locator,int timeout) {
		try {
			WebDriverWait wait=new WebDriverWait(dr,timeout);
			WebElement e=wait.until(
					ExpectedConditions.visibilityOfElementLocated(Locator)
					);
			System.out.println("element located");
			return e;
			
			}catch(Exception e) {
				System.out.println("element not found");
		}
		return null;
	}
	public WebElement clickable(By Locator,int timeout) {
		try {
			WebDriverWait wait=new WebDriverWait(dr,timeout);
			WebElement e=wait.until(ExpectedConditions.elementToBeClickable(Locator));
			System.out.println("element located");
			return e;
			
			}catch(Exception e) {
				System.out.println("element not found");
		}
		return null;
	}
	public void getscreenshot() {
		String path ="C:\\Users\\BLTuser.BLT0192\\Desktop\\nameste";	
		  String filename=counter  + ".png" ;
			
		File f1=  ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		  File f2=new File(path+filename);
		try {
			FileUtils.copyFile(f1,f2);
					
		}
		catch(IOException e)
		{
		
			System.out.println("screen shot no: " + counter + "failed");
			e.printStackTrace();
		}
		counter++;
	}
	public static WebDriver launch_browser(String browser,String url) {
		WebDriver dr=null;
		switch(browser)
		{
		case "CHROME":
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr=new ChromeDriver();
		break;
		
	//	case "FIREFOX":
		//	System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			//dr =new FirefoxDriver();
			//break;
			
	
			
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	
	
}
