package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class royal {
	WebDriver dr;
	public royal(WebDriver dr)
	{
	this.dr=dr;
	}
	public String deckselect() throws InterruptedException {
		Thread.sleep(2000);
		WebElement wb=dr.findElement(By.xpath("//label[@class='deck-dropdown__label']//select"));
		Select dd=new Select(wb);
		dd.selectByVisibleText("Deck Eight");
		Thread.sleep(2000);
		String s1=dr.findElement(By.xpath("//section[@class='deck__info-panel']//following::section[8]//child::h4[1]")).getText();
		return s1;
	}
	

}
