package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class deck {
	WebDriver dr;
	
	public deck(WebDriver dr)
	{
	this.dr=dr;
	}
	public void clkdeck() throws InterruptedException
	{
		 Thread.sleep(20000);
		 dr.findElement(By.xpath("//div[@class='filterSetDestination__base']//div//div[3]")).click();
	}

}
