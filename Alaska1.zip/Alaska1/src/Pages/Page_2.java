package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_2 
{
	WebDriver dr;
	Utilities.wait wt;
	public Page_2(WebDriver dr)
	{
		this.dr=dr;
		wt=new Utilities.wait(dr);
	}
	By plan=By.xpath("//*[@id='rciHeaderSideNavMenu-1']");
	By find=By.xpath("//*[@id='rciHeaderSideNavSubmenu-1-1']");
	public void searchship()
	{
		WebElement e=wt.clickable(plan, 20);
		e.click();
		WebElement e1=wt.clickable(find, 20);
		e1.click();
	}
}
