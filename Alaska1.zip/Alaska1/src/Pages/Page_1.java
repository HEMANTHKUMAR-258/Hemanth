                                      package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_1 
{
	WebDriver dr;
	Utilities.wait wt;
	public Page_1(WebDriver dr)
	{
		this.dr=dr;
		wt=new Utilities.wait(dr);
	}
	By whale=By.xpath("//*[@id='textWithUI-262899300']//a");
	By home=By.xpath("//*[@id='rciHeaderOpenSidenav']");
	public String clickhome()
	{
		WebElement e2=wt.visible(whale, 20);
		String a=e2.getText();
		
		WebElement e1=wt.clickable(home, 20);
		e1.click();
		return a;
	}
}
