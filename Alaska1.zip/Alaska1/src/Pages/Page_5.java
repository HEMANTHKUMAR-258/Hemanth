package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Page_5 
{
	WebDriver dr;
	Utilities.wait wt;
	public Page_5(WebDriver dr)
	{
		this.dr=dr;
		wt=new Utilities.wait(dr);
	}
	By deck=By.xpath("//*[@id='deckDropdown']");
	By royal=By.xpath("//*[@id=\"deck-plans-template\"]/section/section[2]/section[1]/div[2]/section[5]/h4");
	public String royalsuite()
	{
		WebElement e=wt.clickable(deck, 20);
		e.click();
		WebElement e1=wt.visible(deck, 20);
		Select s=new Select(e1);
		s.selectByVisibleText("Deck Eight");
		WebElement e2=wt.visible(royal, 20);
		String a=e2.getText();
		return a;
	}
}
