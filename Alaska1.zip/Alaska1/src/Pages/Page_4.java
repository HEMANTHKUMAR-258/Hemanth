package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_4 
{
	WebDriver dr;
	Utilities.wait wt;
	public Page_4(WebDriver dr)
	{
		this.dr=dr;
		wt=new Utilities.wait(dr);
	}
	By deck=By.xpath("//*[@id=\"siteSearchApp\"]/div[1]/div/div[5]/div[1]/a");
	public void clickdeck()
	{
		WebElement e=wt.clickable(deck, 20);
		e.click();
	}
}
