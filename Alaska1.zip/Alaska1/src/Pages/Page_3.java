package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_3 
{
	WebDriver dr;
	Utilities.wait wt;
	public Page_3(WebDriver dr)
	{
		this.dr=dr;
		wt=new Utilities.wait(dr);
	}
	By search=By.xpath("//*[@id='rciSearchHeaderIcon']");
    By search1=By.xpath("//*[@id='rciSearchInput']");
    By search2=By.xpath("//*[@id='rciSearchInputIcon']");
	public void rhapsodysearch()
	{
		WebElement e=wt.clickable(search, 20);
		e.click();
		WebElement e1=wt.visible(search1, 20);
		e1.sendKeys("Rhapsody of the seas");
		WebElement e2=wt.clickable(search2, 20);
		e2.click();
	}
}
