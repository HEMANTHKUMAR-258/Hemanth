package Test;

import org.testng.annotations.Test;

import Baseclass.Browser_launch;
import Pages.Page_1;
import Pages.Page_2;
import Pages.Page_3;
import Pages.Page_4;
import Pages.Page_5;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class NewTest extends Browser_launch {
	
	WebDriver dr;
	
	Page_1 p1;
	Page_2 p2;
	Page_3 p3;
	Page_4 p4;
	Page_5 p5;
	
	 @BeforeClass
	  public void beforeClass() 
	  {
		 dr=launch("chrome","https://www.royalcaribbean.com/alaska-cruises");
		 
		 p1=new Page_1(dr);
		 p2=new Page_2(dr);
		 p3=new Page_3(dr);
		 p4=new Page_4(dr);
		 p5=new Page_5(dr);
	  }
  @Test
  public void f() 
  {
	  String a=p1.clickhome();
	  p2.searchship();
	  p3.rhapsodysearch();
	  p4.clickdeck();
	  String b=p5.royalsuite(); 
	 Assert.assertTrue((a.equals("whale watching tour") && b.equals("Royal Suite - 1 Bedroom")));
	 
  }
 

  @AfterClass
  public void afterClass() 
  {
	  dr.close();
  }

}
