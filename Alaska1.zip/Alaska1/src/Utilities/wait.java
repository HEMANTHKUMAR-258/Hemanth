package Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class wait
{
	WebDriver dr;
	public wait(WebDriver dr)
	{
		this.dr=dr;
	}
	public WebElement clickable(By loc, int time)
	{
		WebElement e=null;
		WebDriverWait w=new WebDriverWait(dr,time);
		e=w.until(ExpectedConditions.elementToBeClickable(loc));
		return e;
	}
	public WebElement visible(By loc, int time)
	{
		WebElement e=null;
		WebDriverWait w=new WebDriverWait(dr,time);
		e=w.until(ExpectedConditions.visibilityOfElementLocated(loc));
		return e;
	}
}
