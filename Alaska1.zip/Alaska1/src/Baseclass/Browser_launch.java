package Baseclass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser_launch 
{
   WebDriver dr;
public WebDriver launch(String browser, String url)
{
	if(browser.contains("chrome"))
	{
		System.setProperty("webdriver.chrome.driver", "DRIVERS/chromedriver_V79.exe");
		dr=new ChromeDriver();
	}
	dr.get(url);
	dr.manage().window().maximize();
	return dr;
}
}
