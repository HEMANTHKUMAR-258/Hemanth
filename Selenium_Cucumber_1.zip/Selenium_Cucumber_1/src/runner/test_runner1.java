package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="FEATURE",glue="STEP_DEF")

public class test_runner1 extends AbstractTestNGCucumberTests {

}
