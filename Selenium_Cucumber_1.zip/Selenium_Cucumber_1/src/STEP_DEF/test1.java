package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	String exp_title="Online Book Store";
	String act_title=null;
	String test_result;
	
	@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
	}

	@When("^User enters login credentials &clicks on login$")
	public void user_enters_login_credentials_clicks_on_login() throws Throwable {
		System.out.println("^User enters login credentials &clicks on login$");
		dr.findElement(By.xpath("//option[@value='1']")).click();
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	   
	}

	@Then("^Successful login happens & Profile name displayed correctly$")
	public void successful_login_happens_Profile_name_displayed_correctly() throws Throwable {
	    System.out.println("^Successful login happens & Profile name displayed correctly$");
	    if(act_title.equals(exp_title)) {
	    	test_result="pass";
	    }
	    else 
	    {
	    	test_result="Fail";
	    }
	}


}
