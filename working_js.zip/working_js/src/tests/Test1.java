package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void test() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedrver.exe");
	  WebDriver dr=new ChromeDriver();
	  
 	  dr.get("http://demowebshop.tricentis.com/");
 	  
 	  JavascriptExecutor js=()
  }
}
