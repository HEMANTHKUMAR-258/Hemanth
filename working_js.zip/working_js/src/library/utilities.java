package library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class utilities {

	
  WebDriver dr;
  int counter=1;
  
  public  utilities(WebDriver dr) {
	  this.dr=dr;
	  
  }
	public WebElement waitelement(By Locator,int timeout) {
		try {
			WebDriverWait wait=new WebDriverWait(dr,timeout);
			WebElement e=wait.until(
					ExpectedConditions.visibilityOfElementLocated(Locator)
					);
			System.out.println("element located");
			return e;
			
			}catch(Exception e) {
				System.out.println("element not found");
		}
		return null;
	}
	public WebElement clickable(By Locator,int timeout) {
		try {
			WebDriverWait wait=new WebDriverWait(dr,timeout);
			WebElement e=wait.until(ExpectedConditions.elementToBeClickable(Locator));
			System.out.println("element located");
			return e;
			
			}catch(Exception e) {
				System.out.println("element not found");
		}
		return null;
	}

}
