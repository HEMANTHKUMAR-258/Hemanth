

package demo;
import java.util.Scanner;

public class Vote {
	 
	   void checkeligibility() {
		   Scanner sc= new Scanner(System.in);
			  System.out.println("enter the age:");
			  int age = sc.nextInt();
	   if(age >=18){
		   if(age >= 60)
			  
			   System.out.println("senior citizen");
			   else {
				   System.out.println("eligible to vote");
				   System.out.println("not a senior citizen");
				 }
	   }
		   else
			   System.out.println("not eligible to vote");
	   }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vote v= new Vote();
		v.checkeligibility();
	}

}
