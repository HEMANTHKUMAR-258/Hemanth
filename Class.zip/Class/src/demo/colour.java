package demo;
import java.util.Scanner;

public class colour {
	char Col;
	int size;
	void checkc1(){
	Scanner sc= new Scanner(System.in);
	
	System.out.println("enter the colour");
	
	char col=sc.next().charAt(0);
	 switch (col) {
	 case 'r':
	   System.out.println("iam red");
	   break;
	 case 'b':
	 System.out.println("iam black");
	 break;
	 default:
	 System.out.println("iam white");
	 }
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        colour c= new colour();
        c.checkc1();
	}

}
