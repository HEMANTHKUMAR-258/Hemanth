package demo;

public class Marker {
	String colour;
	int size;
	String brand;
	float price;
	void check colour(String colour)
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Marker m1= new Marker();
      Marker m2= new Marker();
      m1.colour="blue";
      m1.size=6;
      m1.brand="celio";
      m1.price=12;
      
	 m2.colour="red";
	 m2.size=7;
	 m2.brand="star";
	 m2.price=15;
	 System.out.println(m1.colour+" "+m1.size+" "+m1.brand+" "+m1.price);
	 System.out.println(m2.colour);
  	}

}
