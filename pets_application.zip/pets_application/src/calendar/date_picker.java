package calendar;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class date_picker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.setProperty("webdriver.chrome.driver","chromedriver.exe");
       WebDriver dr=new ChromeDriver();
       dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
       String exp_month_yr="June 2020";
       String cur_month_yr;
       
       dr.findElement(By.xpath("//input[@id='datepicker']")).click();
      
       cur_month_yr= dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
       System.out.println("exp_month_yr:" +exp_month_yr);
       
       while(!cur_month_yr.equals(exp_month_yr))
       {
    	   dr.findElement(By.xpath("//a[@title='Next']")).click();
    	   cur_month_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
    	   
       }
       
      List<WebElement> rb= dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//child::td"));
       for(WebElement  e: rb )
       {
    	   String date=e.getText();
    	   if(date.equalsIgnoreCase("18"))
    	   {
    		   e.click();
    		   break;
    	   }
       }
	}

}
//table[@class='ui-datepicker-calendar']//child::td