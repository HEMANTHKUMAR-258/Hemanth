package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.class1;
import pages.register;
import pages.signin;
import pages.signup;
import utilities.ExplicitCode;

public class pet_app1_ff {
	WebDriver dr;
	ExplicitCode ec= new ExplicitCode(dr);
	register r;
	signup su;
	signin si;
	class1 c1;
	 @BeforeClass
	  public void beforeClass()
	  {
		 dr= ec.launch_browser("FIREFOX", "https://jpetstore.cfapps.io/catalog");
		 
		 su=new signup(dr);
		 
		 si=new signin(dr);
		 c1=new class1(dr);
	  }
  @Test(priority=0)
  public void f() {
	  c1.call();
  }
  @Test(priority=1)
  public void f1() {
	  si.login("d3825104" ,"hemanth106");
	  
  }
  @AfterClass
  public void afterclass() {
	  dr.close();
  }
  
}
