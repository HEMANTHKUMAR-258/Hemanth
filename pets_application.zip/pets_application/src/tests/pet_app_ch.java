package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.class1;
import pages.log;
import pages.register;
import pages.signin;
import pages.signup;
import utilities.ExplicitCode;

public class pet_app_ch extends log {
	WebDriver dr;
	ExplicitCode ec= new ExplicitCode(dr);
	//register r;
	signup su;
	signin si;
	class1 c1;
	@BeforeClass
	public void beforeClass()
	  {
		dr= ec.launch_browser("CHROME", "https://jpetstore.cfapps.io/catalog");
		update_log("chrome browser launched successfully");
		 
		 //su=new signup(dr);
		// r=new register(dr);
		 si=new signin(dr);
		 c1=new class1(dr);
	  }
	 @Test(priority=0)
	  public void f() {
		 c1.call();
	  }
 
  @Test(priority=1)
  public void f1() {
	  si.login("d3825104" ,"hemanth106");
	 update_log("login sucessfully");
	  
  }
  //@Test(priority=1)
 //public void f1() 
  {
// su.set_regnow();
	  
  }
  //@Test(priority=2)
  public void reg() {
	  
	//  r.login("h3825104", "hemu", "hemu", "hemanth", "kumar","itshemanth258@gmail.com", "9987765578", "howrah", "hello", "kadapa", "Ap", "767", "ind");
  }
  
  
  
  @AfterClass
  public void afterClass()
  {
	  dr.close();
  }
}
