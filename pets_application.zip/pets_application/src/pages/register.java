package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.ExplicitCode;

public class register 
{

	public register(WebDriver dr) 
	{
	  this.dr=dr;
		// TODO Auto-generated constructor stub
	}
	WebDriver dr;
	ExplicitCode  wt=new ExplicitCode (dr);

	By u_name=By.xpath("//input[@id='username']");
    By pwd=By.xpath("//input[@id='password']");
	By r_pwd=By.xpath("//input[@id='repeatedPassword']");
	By f_name=By.xpath("//div[@id='Catalog']//following::input[5]");
	By l_name=By.xpath("//div[@id='Catalog']//following::input[6]");
	By email=By.xpath("//div[@id='Catalog']//following::input[7]");
	By phone=By.xpath("//div[@id='Catalog']//following::input[8]");
	By addr1=By.xpath("//div[@id='Catalog']//following::input[9]");
	By add2=By.xpath("//div[@id='Catalog']//following::input[10]");
	By city=By.xpath("//div[@id='Catalog']//following::input[11]");
	By state=By.xpath("//div[@id='Catalog']//following::input[12]");
	By zip=By.xpath("//div[@id='Catalog']//following::input[13]");
	By country=By.xpath("//div[@id='Catalog']//following::input[14]");
	By lang= By.xpath("//select[@id='languagePreference']");
	By fav=By.xpath("//select[@id='favouriteCategoryId']");
	By list=By.xpath("//div[@id='Catalog']//following::input[15]");//click
	By Banner=By.xpath("//div[@id='Catalog']//following::input[17]");//click
	By save=By.xpath("//input[@id='save']");//click
	

	public void name(String uid) {
		WebElement we_u_name=wt.waitelement(u_name,20);
	we_u_name.sendKeys(uid);
	}
	public void pass(String pd) {
		WebElement we_pwd=wt.waitelement(pwd, 20);
		we_pwd.sendKeys(pd);
	}
	public void rpwd(String rpd) {
		WebElement we_r_pwd=wt.waitelement(r_pwd,20);
	we_r_pwd.sendKeys(rpd);
	}
	public void fname(String fn) {
		WebElement we_f_name=wt.waitelement(f_name,20);
	we_f_name.sendKeys(fn);
	}
	public void lname(String ln) {
		WebElement we_l_name=wt.waitelement(l_name,20);
	we_l_name.sendKeys(ln);
	}
	public void email(String em) {
		WebElement we_email=wt.waitelement(email,20);
	we_email.sendKeys(em);
	}
	public void phone(String pn) {
		WebElement we_phone=wt.waitelement(phone,20);
	we_phone.sendKeys(pn);
	}
	public void addr1(String ar1) {
      WebElement we_addr1=wt.waitelement(addr1,20);
	we_addr1.sendKeys(ar1);
	}
	public void add2(String ar2) {
		WebElement we_add2=wt.waitelement(add2,20);
	         we_add2.sendKeys(ar2);
	}
	public void city(String ct) {
		WebElement we_city=wt.waitelement(city,20);
		we_city.sendKeys(ct);
	}
	public void state(String  st) {
		WebElement we_state=wt.waitelement(state,20);
		we_state.sendKeys(st);
		
	}
	public void zip(String zp) {
		WebElement we_zip=wt.waitelement(zip, 20);
		we_zip.sendKeys(zp);
	}
	public void country(String ct1) {
		WebElement we_country=wt.waitelement(country, 20);
		we_country.sendKeys(ct1);
		}
	public void lan() {
		WebElement we_lang=wt.waitelement(lang, 20);
		we_lang.click();
	}
	public void fa() {
		WebElement we_fav=wt.waitelement(fav, 20);
		we_fav.click();
	}
	public void list() {
		WebElement we_list=wt.waitelement(list, 20);
		we_list.click();
	}
	public void Ban() {
		WebElement we_Banner=wt.waitelement(Banner,20);
		we_Banner.click();
	}
	public void save() {
		WebElement we_save=wt.waitelement(save,20);
		we_save.click();
	}
	
	public void login(String uid,String pd,String rpd,String fn,String ln,String em,String pn,String ar1,String ar2,String ct,String st,String zp,String ct1 ) {
		this.name(uid);
		this.pass(pd);
		this.rpwd(rpd);
		this.fname(fn);
		this.lname(ln);
		this.email(em);
		this.phone(pn);
		this.addr1(ar1);
		this.add2(ar2);
		this.city(ct);
		this.state(st);
		this.zip(zp);
		this.country(ct1);
		this.lan();
		this.fa();
		this.list();
		this.Ban();
		this.save();
	
	}
	
}
