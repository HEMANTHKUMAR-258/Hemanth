package pages;


import java.util.logging.Logger;

public class log {
  
   
 
   
   public void update_log(String h) {
	   Logger log= Logger.getLogger("devpinoyLogger");
	   
	   log.info(h);
   }
}
