package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signup {
   
	
	By signin=By.xpath("//div[@id='Menu']//child::a[2]");//click
	By regnow=By.xpath("//a[@href='/accounts/create?form']");//click
 

WebDriver dr;
public   signup(WebDriver dr) {
	this.dr=dr;
}

public void set_signin() {
	dr.findElement(signin).click();
}
public void set_regnow() {
	dr.findElement(regnow).click();
}










}
