package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.ExplicitCode;

public class class1 {
	By signin=By.xpath("//div[@id='Menu']//a[2]");//click
	WebDriver dr;
	ExplicitCode wt;
	public  class1(WebDriver dr) {
		this.dr=dr;
		  wt=new ExplicitCode (dr);
	}

	public void signing() {
		WebElement we_signin=wt.waitelement(signin ,20);
		we_signin.click();
	}
  public void call() {
	   this.signing();
   }
}
