package bookstore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import library.utilities;

public class page_1 {
	
	WebDriver dr;
      utilities d;
	public page_1(WebDriver dr) {
		this.dr=dr;
		d= new utilities(dr);
		
		
	}
	
	By product=By.xpath("//select[@name ='category_id']");
	By click=By.xpath("//input[@name ='DoSearch']");
	
	public void product(String p) {
		WebElement pr=d.waitelement(product,20);
		Select a=new Select(pr);
		a.selectByVisibleText(p);
	}
	public void search() {
		WebElement s=d.waitelement(click,20);
		s.click();
	}
	public void do_search(String p)
	{
		this.product(p);
		this.search();
	}
	public String get_title() {
		return dr.getTitle();
	}

}
