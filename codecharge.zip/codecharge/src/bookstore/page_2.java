package bookstore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Wait;

import library.utilities;

public class page_2 {
	WebDriver dr;
	utilities d;
	 
	By name=By.xpath("//table[@class='Grid']//b//following::a[2]");
	
	public page_2(WebDriver dr) {
		this.dr=dr;
		d=new utilities(dr);
		}
	public String get_title() {
		
		return dr.getTitle();
	}
	public String get_bookname() {
		WebElement b=d.waitelement(name,20);
		String a=b.getText();
		return a;
	}

}
