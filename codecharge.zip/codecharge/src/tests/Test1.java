package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import bookstore.page_1;
import bookstore.page_2;

public class Test1 {
	WebDriver dr;
	page_1 p1;
	page_2 p2;
	@BeforeClass
	public void beforeclass() 
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		dr.manage().window().maximize();
	}
  @Test(priority=0)
  public void Title1() {
	  p1=new page_1(dr);
	  String a=p1.get_title();
	  Assert.assertTrue(a.equals("Online Bookstore"));
	  p1.do_search("programming");
	  
  }
  //@Test(priority=1)
  public void Title2() {
	  p2=new page_2(dr);
	  String a=p2.get_title();
	  Assert.assertTrue(a.equals("SearchResults"));
	  
  }
  //@Test(priority=2)
  public void Bookname() {
	  
	  String a=p2.get_bookname();
	  Assert.assertTrue(a.equals("Perl and CGI for the World Wide WEB"));
	  
  }
  //@AfterClass
  public void ac() {
	  dr.close();
  }
}
