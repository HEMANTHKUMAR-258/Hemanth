package tests;

public @interface BeforeClass {

}
