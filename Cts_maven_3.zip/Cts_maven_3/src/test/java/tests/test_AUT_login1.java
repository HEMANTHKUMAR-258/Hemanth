package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASS.ExplicitCode;
import pages.AUT_home_page;
import pages.AUT_login_page;

public class test_AUT_login1 extends ExplicitCode{
	
	AUT_login_page loginpage;
	AUT_home_page  homepage;
	@BeforeMethod
	public void launch_browser(){
		
		String url="http://demowebshop.tricentis.com/login";	
		launch_browser("chrome",url);
	}
	@BeforeClass
	public void getexcel1() {
		System.out.println("In Before clss");
		getexcel();
	}
  @Test(dataProvider="login data")
  public void test_login_page(String un,String pwd,String e_eid)
  {
	  System.out.println(un +pwd);
	  String e=e_eid;
	  loginpage=new AUT_login_page(dr);
	   homepage= new  AUT_home_page(dr);
	  loginpage.login(un,pwd);
	  String actual_eid=homepage.get_displayed_eid();
	  Assert.assertTrue(actual_eid.contains(e));
	  dr.close();
  }
  @DataProvider(name="login data")
  public String[][] dp() 
  {
	  System.out.println("In Data Provider");
	   return testdata;
	  
  }
//  @Test(priority=1)
//  public void test_home_page(){
//	  loginpage.login("tirumalashetty.harika@gmail.com","anjaneya9$");
//	  homepage =new AUT_home_page(dr);
//	  String actual_eid=homepage.get_displayed_eid();
//	  Assert.assertTrue(actual_eid.contains("tirumalashetty.harika@gmail.com"));
//	  
//  }
}
