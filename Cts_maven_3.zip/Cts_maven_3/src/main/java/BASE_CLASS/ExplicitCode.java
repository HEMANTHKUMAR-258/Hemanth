package BASE_CLASS;




import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import excel_utility.registration1;


public class ExplicitCode extends registration1 {
	 protected WebDriver dr;
	
	
	
//	public void getscreenshot() {
//		String path ="C:\\Users\\BLTuser.BLT0192\\Desktop\\nameste";	
//		  String filename=counter  + ".png" ;
//			
//		File f1=  ((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
//		  File f2=new File(path+filename);
//		try {
//			FileUtils.copyFile(f1,f2);
//					
//		}
//		catch(IOException e)
//		{
//		
//			System.out.println("screen shot no: " + counter + "failed");
//			e.printStackTrace();
//		}
//		counter++;
//	}
	public  WebDriver launch_browser(String browser,String url) {
		System.out.println("Launching the browser");
	
		if(browser.contains("chrome"))
		{
	     String ch_driver="src\\test\\resources\\DRIVERS\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", ch_driver);
		dr=new ChromeDriver();

		
	//	case "FIREFOX":
		//	System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			//dr =new FirefoxDriver();
			//break;
			
	
			
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
	}
	
	
}
