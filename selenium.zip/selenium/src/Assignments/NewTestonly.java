package Assignments;

import org.testng.annotations.Test;

public class NewTestonly {
  @Test
  public void t1() {
	  System.out.println("in t1:before");
	  try{
		  Thread.sleep(5000);
		  
	  }catch(InterruptedException e)
	  {
		  e.printStackTrace();
	  }
	  System.out.println("in t1 :after");
  }
  @Test
  public void t2() {
	  System.out.println("in t2:before");
	  try{
		  Thread.sleep(5000);
		  
	  }catch(InterruptedException e)
	  {
		  e.printStackTrace();
	  }
	  System.out.println("in t2:after");
}
}
