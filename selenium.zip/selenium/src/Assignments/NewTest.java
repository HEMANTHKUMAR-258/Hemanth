package Assignments;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

public class NewTest extends registration{
	
	
	 @BeforeClass
	  public void beforeClass() {
		getexcel();
	  }
	// @Test
	// public void t1(){
	///	 System.out.println(testdata[0][1]  " + " testdata[0][2] " " +);
	 
  @Test(dataProvider = "dp")
  public void callingregister(String fn,String ln,String email,String pwd,String cpwd,String E_result) {
	  register(fn,ln,email,pwd,cpwd);
  }

  @DataProvider(name="dp")
  public String[][] dp() {
       return testdata;
    };
  }
 


