package Assignments;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest1 extends registration1{
	  @BeforeClass
	  public void beforeclass() {
	 
	 getexcel();
	  }
	 
	  @Test(dataProvider = "dp")
	  public void calllogin(String FirstName,String LastName,String Email,String Password ,String cp,String E_Results) throws IOException {
	 
	 
	 String A_Results=DemoRegister(FirstName,LastName,Email,Password,cp);
	 SoftAssert sa=new SoftAssert();
	 sa.assertEquals(E_Results, A_Results);
	 sa.assertAll() ;
	 
	  }


	  @DataProvider(name ="dp")
	  public String[][] dp() {
	 
	 return testdata;
	   
	    };
}
