package Assignments;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xslf.usermodel.XSLFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class registration {


	 static String[][] testdata=new String[2][5];
	

	
	public void register(String fn,String ln,String email,String pwd,String cpwd){
  try{
	  
  
		System.out.println("in register method");
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
	
		dr.findElement(By.xpath("//div[@class='header-links']//child::a[1]")).click();
		List rb= dr.findElements(By.xpath("//input[@value='M']"));
		
	   ((WebElement)rb.get(0)).click();
		
		
	 dr.findElement(By.xpath("//div[@class='fieldset']//following::input[3]")).sendKeys(fn);//firstname
	 dr.findElement(By.xpath("//div[@class='fieldset']//following::input[4]")).sendKeys(ln);//lastname
	 dr.findElement(By.xpath("//div[@class='fieldset']//following::input[5]")).sendKeys(email);//em id
	 dr.findElement(By.xpath("//div[@class='fieldset']//following::input[6]")).sendKeys(pwd);//password
	 dr.findElement(By.xpath("//div[@class='fieldset']//following::input[7]")).sendKeys(cpwd);//confirm
	 dr.findElement(By.xpath("//input[@id='register-button']")).click();//register
	 
	 String h=dr.findElement(By.xpath("//a[@class='account']")).getText();//registeredmailid
	 if(h.equals(email)){
		String h1= dr.findElement(By.xpath("//div[@class='result']")).getText();
		System.out.println(h1);
	 }else
	 {
		 String h2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		 System.out.println(h2);
				 
	 }
	 
	 if(fn.equals("pawan")){
		 File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		 File f2=new File("C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\photo.jpg");
		 try {
			FileUtils.copyFile(f1,f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	 }else{
		 File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		 File f2=new File("C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\photo1.jpg");
		 try {
			FileUtils.copyFile(f1,f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
  }catch(NoSuchElementException e){
	  e.printStackTrace();
  }
	}
	
	public static String[][] getexcel(){
		 WebDriver dr;
		
		try{
			
			System.out.println("In getExcel");
			File f=new File("C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\register.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			for(int r=0;r<=1;r++){
				XSSFRow R=sh.getRow(r);
				for(int c=0;c<=4;c++){
					XSSFCell C=R.getCell(c);
					testdata[r][c]=C.getStringCellValue();
				}
			}
				
		}catch(FileNotFoundException e){
			
			e.printStackTrace();
		}catch(IOException e){
			
			e.printStackTrace();
		}
		return testdata;
	}

}
