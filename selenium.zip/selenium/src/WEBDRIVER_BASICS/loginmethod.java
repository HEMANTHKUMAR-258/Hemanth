package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginmethod {
	
	
	public void login(String eid,String pwd){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys(eid);
	    dr.findElement(By.id("Password")).sendKeys(pwd);
	    
	    dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     loginmethod lm=new loginmethod();
     lm.login("hemanthkumardevaki1@gmail.com","8331830704");
	}

}
