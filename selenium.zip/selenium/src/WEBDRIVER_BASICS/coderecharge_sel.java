package WEBDRIVER_BASICS;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class coderecharge_sel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		      System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		      WebDriver dr= new ChromeDriver();
		      dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		      dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("dHemanthkumar");
		      dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("hemanth106");
		      dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("Hemanth");
		      dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Kumar");
		       dr.findElement(By.xpath("//input[@name='email']")).sendKeys("itshemanth258@gmail.com");
		        dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("2/936","devaki nagar","kadapa");
		        dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Cuddapah");
		      dr.findElement(By.xpath("//select[@name='state_id']//option[18]")).click();
		      dr.findElement(By.xpath("//select[@name='country_id']//option[113]")).click();
		      try{
		    	  dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("988765456");
		      }catch(NoSuchElementException exception){
		           System.out.println("getting Errors");
		      }
		      
		      dr.findElement(By.xpath("//select[@name='age_id']//option[3]")).click();
		      dr.findElement(By.xpath("//select[@name='gender_id']//option[3]")).click();
		      dr.findElement(By.xpath(" //select[@name='education_id']//option[3]")).click();
		      dr.findElement(By.xpath("//select[@name='income_id']//option[3]")).click();
		      dr.findElement(By.xpath("//input[@name='Insert']")).click();
		      String name="hemanth";
		      dr.findElement(By.xpath("//input[@name='s_keyword']")).sendKeys(name);
		      String s=dr.findElement(By.xpath("//input[@name='s_keyword']")).getText();
		      
		       
		      int r=s.compareTo(name);
		      if(r==0){
		    	  System.out.println("registered succesfully");
		      }else{
		    	  System.out.println("registration unsuccesfull");
		      }
		      
		      
		    		  dr.findElement(By.xpath("//input[@value='Search']")).click();
			}

		
	}


