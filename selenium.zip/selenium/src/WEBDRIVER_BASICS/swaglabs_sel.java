package WEBDRIVER_BASICS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class swaglabs_sel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr =new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	
	
		
		dr.findElement(By.xpath("//input[@class='form_input']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[2][@class='form_input']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@class='btn_action']")).click();
		
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String p1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][1]")).getText();
		String p2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][2]")).getText();
		String pr1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][1]")).getText();
		String pr2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][2]")).getText();
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(pr1);
		System.out.println(pr2);
		
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[1]")).click();
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[2]")).click();

		dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
		
		String actualname=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
		String actualname1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
		String actualprice1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
		String actualprice2=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();
		
		if(p1.equals(actualname)&&p2.equals(actualname1)){
			System.out.println("products name matched");
		}
		else{
			System.out.println("Not Matched");
		}
		if(pr1.substring(1).equals(actualprice1) && pr2.substring(1).equals(actualprice2)){
			System.out.println("products price Matched");
		}
		else{
			System.out.println("price not Matched");
		}
		
		
		
	}

}
