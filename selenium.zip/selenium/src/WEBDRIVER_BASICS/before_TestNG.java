package WEBDRIVER_BASICS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class before_TestNG {
	login_testng  ltg;
  @Test
  public void beforeMethod() {
	  ltg =new login_testng();
  }
@Test
  public void t1(){
	  ltg.login();
	  
}
}