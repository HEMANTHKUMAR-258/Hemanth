package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class webdriver_wait 
{
      static WebDriver dr;
      static WaitTypes wt;
      public webdriver_wait(WebDriver dr)
      {
    	  this.dr=dr;
      }

      public static  String login(String uid, String pwd) 
      {
    	  wt= new WaitTypes(dr);
    	  String a_result;
    	  
    	  By by_eid=By.xpath("//input[@class='email']");
    	  WebElement we_eid=wt.waitForElement(by_eid,20);
    	  we_eid.sendKeys(uid);
    	  
    	  By by_pwd=By.xpath("//input[@class='Password']");
    	  WebElement we_eid=wt.waitForElement(by_eid,20);
    	  we_pwd.sendKeys(pwd);
    	  
    	  By by_btn=By.xpath("//input[@value='Log_in']");
    	  WebElement we_eid=wt.waitForElement(by_eid,20);
    	  we_btn.click();
    	  
    	}

}
