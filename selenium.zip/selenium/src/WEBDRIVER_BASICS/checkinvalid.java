package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class checkinvalid {
	public String login_inv(String eid,String pwd){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		 dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		  dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		String s1=  dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		 String s2= dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		 String s3=s1.concat(s2);
		 return s3;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
	checkinvalid lo=new checkinvalid();
	
         String act  =lo.login_inv("itshemanth258@gmail.com"," hemanth106");
         String act1  =lo.login_inv("itshemanth258@gmail.com", " ");
         String act2  =lo.login_inv(" ", " hemanth106");
	String excep="Login was unsuccessful. Please correct the errors and try again.The credentials provided are incorrect";
	
	if(excep.equals(act)==true){
		System.out.println("pass");
	}
	else{
		System.out.println("Fail");
		
	}
	}
}