
		package WEBDRIVER_BASICS;

		import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.chrome.ChromeDriver;

		public class codechargeapp_sel
		{

		public static void main(String[] args)
		{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("Tejasri");
		dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("Passion");
		dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("Tejasri");
		dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("M B");
		dr.findElement(By.xpath("//input[@name='email']")).sendKeys("teju3tejasri@gmail.com");
		dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("Dollor Colony");
		dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Delhi");
		dr.findElement(By.xpath("//select[@name='state_id']//child::option[18]")).click();
		dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("30512");
		dr.findElement(By.xpath("//select[@name='country_id']//child::option[113]")).click();
		dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("22228389");
		dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("9676395565");
		dr.findElement(By.xpath("//select[@name='language_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//select[@name='age_id']//child::option[3]")).click();
		dr.findElement(By.xpath("//select[@name='gender_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//select[@name='education_id']//child::option[3]")).click();
		dr.findElement(By.xpath("//select[@name='income_id']//child::option[4]")).click();
		dr.findElement(By.xpath("//textarea[@ name = 'note']")).sendKeys("A passsionate young professional intended to develop the skills professionally and personally.");
		dr.findElement(By.xpath("//input[@value='Register']")).click();
		
		}
	}


		
		

	