package WEBDRIVER_BASICS;

import org.testng.annotations.Test;

public class newtest1 {
  @Test
  public void intt1() {
	  System.out.println("in test t1");
	  
  }
  @Test
  public void intt2(){
	  System.out.println("in test t2");
	  
  }
  @Test
  public void intt3(){
	  System.out.println("in test t3");
  }
}
