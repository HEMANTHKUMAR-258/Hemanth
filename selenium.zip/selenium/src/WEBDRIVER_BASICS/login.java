package WEBDRIVER_BASICS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	login  e= new login();
		   System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 //  String s = "itshemanth258@gmail.com";
		   
		   WebDriver dr =new ChromeDriver();
		      dr.get("http://demowebshop.tricentis.com");
		      dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		     // dr.findElement(By.linkText(" Log in")).click();
		      dr.findElement(By.id("Email")).sendKeys("it8@gmail.com");
		      
		  dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		  
		      

       
        String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
        System.out.println(s1);
        String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
        System.out.println(s2);
       
	}
}

	

