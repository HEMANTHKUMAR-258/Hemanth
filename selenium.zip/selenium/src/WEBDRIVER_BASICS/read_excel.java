package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class read_excel {
	public String readdata(String f_name,String s_name, int r, int c){
		String s1=null;
		File f=new File(f_name);
	
		try{
			FileInputStream fis= new FileInputStream(f_name);
			XSSFWorkbook wb =new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet(s_name);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell= row.getCell(c);
			 s1= cell.getStringCellValue();
			}
		
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s1;
	}
		public void writedata(String fname,String sname, int r,int c,String s){
		
			String s1=null;
			File f=new File(fname);
			
			try{
				
				FileInputStream fis=new FileInputStream(fname);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet(sname);
				XSSFRow row=sh.getRow(r);
				XSSFCell cell=row.createCell(c);
				cell.setCellValue(s);
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
				}
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
	    }
		
	}
		public String login(String eid,String pwd){
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			WebDriver dr=new ChromeDriver();
			
			dr.get("http://demowebshop.tricentis.com/");
			dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
			dr.findElement(By.id("Email")).sendKeys(eid);
		    dr.findElement(By.id("Password")).sendKeys(pwd);
		    
		    dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		    String s3=dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();
		    
		    return s3;
}
			public static void main(String[] args) {
		// TODO Auto-generated method stub
        read_excel e1=new read_excel();
        String p="C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\rwrite.xlsx";
        String t="Sheet1";
        String Testresult;
        int r;
        for(r=1;r<=2;r++){
             
        
        String s1=e1.readdata (p,t,r,0);
        String s2=e1.readdata (p,t,r,1);
        
        String actualresult=e1.login(s1, s2);
        e1.writedata("p","t",r,3,actualresult);
        
        String s4= e1.readdata(p,t,r,2);
        
        int m=s1.compareTo(s4);
        if(m==0){
        	Testresult="pass";
        }else{
        	Testresult="fail";
        }
        e1.writedata(p,t,r,4,Testresult);
			}
			
      }


}