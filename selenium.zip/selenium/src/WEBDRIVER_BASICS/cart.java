package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		login  e= new login();
		   System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 //  String s = "itshemanth258@gmail.com";
		   
		   WebDriver dr =new ChromeDriver();
		      dr.get("http://demowebshop.tricentis.com");
		     dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		    // dr.findElement(By.linkText(" Log in")).click();
		      dr.findElement(By.id("Email")).sendKeys("hemanthkumardevaki1@gmail.com");
		      dr.findElement(By.id("Password")).sendKeys("8331830704");

		      
		  dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		  dr.findElement(By.xpath("//div[@class='header-links']//child::li[3]")).click();
		//  dr.findElement(By.xpath("//table[@class='cart-header-row']//child::tr[2] ")).click();
		 dr.findElement(By.xpath("//td[@class='remove-from-cart']//child::input")).click();
		    //dr.findElement(By.xpath("//tr[@class='cart-item-row']//child::input[1]")).click();
		  dr.findElement(By.xpath("//div[@class='common-buttons']//child::input[1]")).click();
		 
		  
		  dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).clear();
		  dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).sendKeys("2");
		  dr.findElement(By.xpath("//div[@class='common-buttons']//child::input[1]")).click();
		  
		  
		      
		  
    
     String s1=dr.findElement(By.xpath("//td[@class='remove-from-cart']//child::input")).getText();
     System.out.println(s1);
     String s2=dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).getText();
     //System.out.println(s2);
    
	}

}
