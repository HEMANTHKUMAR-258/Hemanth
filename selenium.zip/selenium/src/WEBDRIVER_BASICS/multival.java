package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public static String readdata(String f_name,String s_name)
{
	
	File f=new File(f_name);
	String s1=null;

	try{
		FileInputStream fis= new FileInputStream(f_name);
		XSSFWorkbook wb =new XSSFWorkbook(fis); 
		XSSFSheet sh= wb.getSheet(s_name);
		XSSFRow row=sh.getRow(r);
		XSSFCell cell= row.getCell(ce);
		 s1= cell.getStringCellValue();
		}
	
	catch (FileNotFoundException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	catch (IOException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s1;
}

public class multival {
	public String login_inv(String email,String password){
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		 dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		  dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		String s1=  dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		 String s2= dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		 String s3=s1.concat(s2);
		 return s3;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
