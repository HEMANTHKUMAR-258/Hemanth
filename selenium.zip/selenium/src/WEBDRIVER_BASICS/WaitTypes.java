package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes {
	private static final String ExceptedConditions = null;

	public void waitTypes(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public WebElement waitForElement(By locator,int timeout) {
		try {
			WebDriverWait wait= new WebDriverWait(driver,timeout);
			WebElement element =wait.until(
					ExceptedConditions.visibilityofElementLocated(locator)
					);
			System.out.println("Element Located");
			
			return element;
		}catch(Exception e) {
			System.out.println("Element not Located" + e);
			
		}
		return null;
	}
	
	public WebElement elementToBeClickable(By locator,int timeout)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(dr,timeout);
			
			WebElement element =wait.until(
					ExceptedConditions.visibilityofElementLocated(locator);
					
		}
	}
	
	

}
