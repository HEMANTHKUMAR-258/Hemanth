package WEBDRIVER_BASICS;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class selection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		 dr.get("http://demowebshop.tricentis.com/accessories");
		 int k=5;
		String xp="//div[@class='item-box']["+k+"]//child::input";
			
	}

}
