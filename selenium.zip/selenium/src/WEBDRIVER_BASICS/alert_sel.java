package WEBDRIVER_BASICS;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class alert_sel {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       WebDriver dr;
       
       System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
       dr= new ChromeDriver();
       dr.get("http://demo.guru99.com/test/delete_customer.php");
       
       dr.findElement(By.xpath("//input[@type='text']")).sendKeys("jsdfsf");
       dr.findElement(By.xpath("//input[@type='submit']")).click();
       try{
    	   Thread.sleep(3000);
       }
      catch(InterruptedException e){
    	  e.printStackTrace();
       }
       
	 Alert a=dr.switchTo().alert();
	 String s=a.getText();
	 System.out.println(s);
	// a.accept();
	 a.dismiss();
	 try{
		 Thread.sleep(3000);
		 
	 }catch(InterruptedException e){
		 e.printStackTrace();
	 }
		 Alert a1=dr.switchTo().alert();
		 s=a1.getText();
		 a1.dismiss();
		 System.out.println(s);
		 
	 }

}
