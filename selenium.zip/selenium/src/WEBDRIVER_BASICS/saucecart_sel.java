package WEBDRIVER_BASICS;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class saucecart_sel {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr =new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	
	
		
		dr.findElement(By.xpath("//input[@class='form_input']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[2][@class='form_input']")).sendKeys("secret_sauce");
		//dr.findElement(By.xpath("//input[@class='btn_action']")).click();

		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File("C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\1.png");
		FileUtils.copyFile(f1, f2);


}
}