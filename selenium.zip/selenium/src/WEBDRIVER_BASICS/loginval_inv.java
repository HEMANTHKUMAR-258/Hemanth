package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginval_inv {
	public static String readdata(String f_name,String s_name ,int r,int c)
	{
		
		File f=new File("f_name");
		String s=null;

		try{
			FileInputStream fis= new FileInputStream(f_name);
			XSSFWorkbook wb =new XSSFWorkbook(fis); 
			XSSFSheet sh= wb.getSheet(s_name);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell= row.getCell(c);
			 s= cell.getStringCellValue();
			}
		
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	public static String writedata (String fname,String sname,int r, int c,String k)
	{
		File f=new File(fname);
		String s1=null;
		
		try{
			FileInputStream fis=new FileInputStream(fname);
			XSSFWorkbook wb =new XSSFWorkbook(fis); 
			XSSFSheet sh= wb.getSheet(sname);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell= row.createCell(c);
			cell.setCellValue(k);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			 
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 
			
		
			
		return s1;
	}
	 
public static String login ( String eid,String pwd){
	System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/login");
	
	dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
	dr.findElement(By.id("Email")).sendKeys(eid);
    dr.findElement(By.id("Password")).sendKeys(pwd);
    
    dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
    String h;
    if(eid.contains("@gmail.com")==true)
    {
    	h=dr.findElement(By.xpath("//div[@class='header-links']//following::a[1]")).getText();
    	if(h.equals("Register"))
        h=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
    }
    else{
    	h=dr.findElement(By.xpath("//span[@class='field-validation-error']//child::span")).getText();
    }
	dr.close();return h;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      loginval_inv lv=new loginval_inv();
      String link="C:\\Users\\BLTuser.BLT0192\\Desktop\\nameste\\hello.xlsx";
      String s="sheet1";
      String Testresult;
      int r;
      for(r=0;r<=3;r++){
    	  String b= lv.readdata(link,s,r,0);
    	  String c=lv.readdata(link,s,r,1);
    	  String actual=login(b,c);
    	  String Excepted=lv.readdata(link, s, r, 2);
         
          if(Excepted.equals(actual)==true){
        	  Testresult="pass";
          }
          else{
        	  Testresult="fail";
          }
    	  writedata(link,s,r,3,actual);
    	  writedata(link,s,r,4,Testresult);
      }
	}

}
