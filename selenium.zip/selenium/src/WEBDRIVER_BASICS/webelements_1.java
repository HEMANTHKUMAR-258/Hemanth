package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class webelements_1 {

	private static final String ExceptedConditions = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.setProperty("webdriver.chrome.driver","chromedriver.exe");
      String t="itshemanth258@gmail.com";
      
      WebDriver dr =new ChromeDriver();
      dr.get("http://demowebshop.tricentis.com");
      
      //dr.findElement(By.linkText("Log in")).click();
      //dr.findElement(By.id("Email")).sendKeys("itshemanth258@gmail.com");
      //dr.findElement(By.id("Password")).sendKeys("Hemanth106");
      
      String xp="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a";
      WebElement we;
      WebDriverWait wt =new WebDriverWait(dr,20);
      we=wt.until(ExceptedConditions.elementTobeclickable(By.xpath(xp)));
      we.click();
      //String xp= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
      //String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
      //int p=s.compareTo(t);
      /*if(p==0)
    	  System.out.println("pass");
      else
    	  System.out.println("fail");
      
	*/}

}
