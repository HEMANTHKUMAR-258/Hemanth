package Test_ng;

import org.testng.annotations.Test;

public class priority_ng {
  @Test(priority=13)
  public void f() {
	  System.out.println("in test method t1");
  }
  @Test(priority=5)
  public void r(){
	  System.out.println("in test method t3");
  }
  @Test(priority=6)
  public void g(){
	  System.out.println("in test method t2");
  }
}
