package Test_ng;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import WEBDRIVER_BASICS.login;

public class NewTestDatapro {
	
	dataprovider_login e;
  @Test(dataProvider="login_data")
  public void login(String eid,String pwd,String exp_eid) {
	   e= new dataprovider_login();
	  String act_id=e.login1(eid,pwd);
	  
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(act_id, exp_eid);
	  sa.assertAll();
	  
	  
	  //System.out.println("email id:" +eid+ "pwd:" +pwd+ "excepted res:" +expres);
  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
	  String[][] data= {
			
			  {"tirumalashetty.harika@gmail.com","anjaneya9$","tirumalashetty.harika@gmail.com"},
			  {"tirumalashetty.harika@gmail.com","anjaneya9$","tirumalashetty.harika1@gmail.com"}
	  };
	  return data;
  }
}
