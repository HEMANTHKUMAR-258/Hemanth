package Test_ng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragandDrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.driver", "chromedriver");
		WebDriver driver = new ChromeDriver();
		
		String URL="https://demoqa.com/droppable/";
		driver.get(URL);
		
		driver.manage().window().maximize();
		
		Actions builder= new Actions(driver);
		
		WebElement from = driver.findElement(By.xpath("//div[@id='draggable']"));
		
		WebElement to = driver.findElement(By.xpath("//div[@id='droppable']"));
		
		builder.dragAndDrop(from, to).perform();
		
		String textTo=to.getText();
		
		if(textTo.equals("Dropped!"))
		{
			System.out.println("PASS:drag &drop successful");
		}else
			System.out.println("FAIL: drag &drop unsuccessful ");
		
		
		
		

	}

}
