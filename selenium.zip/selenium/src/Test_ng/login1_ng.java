package Test_ng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class  login1_ng {

	WebDriver  dr;
	String an,ap,en1,ep1;
	public WebDriver login(String eid,String pwd){
		System.setProperty("webdriver.driver", "chromedriver");
		dr =new ChromeDriver();
		dr.get("https://www.saucedemo.com/");

		dr.findElement(By.xpath("//input[@class='form_input']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[2][@class='form_input']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@class='btn_action']")).click();
		return dr;
	}
	public void add_prod(int n){
		
		  en1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name']["+n+"]")).getText();
	
		  
	    ep1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price']["+n+"]")).getText();
	    dr.findElement(By.xpath("//div[@class='inventory_list']//following::button["+n+"]")).click();
	    dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a")).click();
		
		
		
		
	}
/*	public void verify(int n){
		
		
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 ap=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name']["+n+"]")).getText();
		 
	                                      
		 an=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price']["+n+"]")).getText();
		 System.out.println(en1);
		 System.out.println(ep1);
		 System.out.println(ap);
		 System.out.println(an);
		if(en1.equals(an)){
			System.out.println("product name matched");
		}
			else
			{
				System.out.println("products names are not matched");
			
		}
			if(ap.substring(1).equals(ep1)){
				System.out.println("price is same");
				
			}else
			{
				System.out.println("price is not same");
			}
			
	}*/
			public void add_info(){
				dr.findElement(By.xpath("//input[@id='first-name']")).sendKeys("Hemanth");
			dr.findElement(By.xpath("//input[@id='last-name']")).sendKeys("Kumar");
			dr.findElement(By.xpath("//input[@id='postal-code']")).sendKeys("516001");
			dr.findElement(By.xpath("//input[@class='btn_primary cart_button']")).click();
		dr.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();
	
			
			
}}


