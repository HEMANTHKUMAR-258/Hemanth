package Test_ng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import WEBDRIVER_BASICS.login;

public class dataprovider_login {

	public String login1(String eid, String pwd){
	
	login  e1= new login();
	   System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	   // String s = "itshemanth258@gmail.com";
	   
	   WebDriver dr =new ChromeDriver();
	      dr.get("http://demowebshop.tricentis.com");
	      dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
	    
	      dr.findElement(By.id("Email")).sendKeys(eid);
	      dr.findElement(By.id("Password")).sendKeys(pwd);
	     // dr.findElement(By.linkText(" Log in")).click();
	    
	  dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	  String s1=dr.findElement(By.xpath("//div[@class='header-links']//following::a[1]")).getText();
	  return s1;
	  
	  
}
}