package Test_ng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login_ng {
	
		// TODO Auto-generated method stub
		WebDriver dr;
		

		public void login(String eid,String pwd){
			
			dr.findElement(By.xpath("//input[@class='form_input']")).sendKeys(eid);
			dr.findElement(By.xpath("//input[2][@class='form_input']")).sendKeys(pwd);
			dr.findElement(By.xpath("//input[@class='btn_action']")).click();

		}

		public login_ng(WebDriver dr)
		{
			// TODO Auto-generated constructor stub
			this.dr=dr;
		}
		
		
			

	}


