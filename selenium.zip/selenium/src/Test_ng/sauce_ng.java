package Test_ng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class sauce_ng {
	WebDriver dr;
	login1_ng lg=new login1_ng ();
	int p[] ={1,2};
	int i=0;
	
	@BeforeClass
	public  void beforeclass(){
		
		
	
	dr=	lg.login("standard_user", "secret_sauce");
	}	
	
	@BeforeMethod
	public void bm()
	{
		lg.add_prod(p[i]);
	}
    @Test(priority=0)
  public void t1 () {
    	
    	String an=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
		 
         
		String ap=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
		SoftAssert sa= new SoftAssert();
		sa.assertEquals(an,lg.en1 );
		sa.assertEquals(ap, lg.ep1.substring(1));
		sa.assertAll();
  }
    @Test(priority=1)
    public void t2(){
    	String an=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
		 
        
		String ap=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();
		SoftAssert sa= new SoftAssert();
		sa.assertEquals(an,lg.en1 );
		sa.assertEquals(ap, lg.ep1.substring(1));
		sa.assertAll();
		
    }
    @AfterMethod
   public void aftermethod(){
    	if(i<1){
    		dr.findElement(By.xpath("//div[@class='cart_footer']//a[1]")).click();
    	}else
		
		dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
    	i++;
    }
    @AfterClass 
    public void add(){
    	lg.add_info();
    }
}
