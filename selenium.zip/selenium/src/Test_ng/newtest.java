package Test_ng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverInfo;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import WEBDRIVER_BASICS.login_testng;

public class newtest {
	WebDriver dr;
	login_ng jobj;
	@BeforeMethod
	 public void beforeMethod() {
		 System.setProperty("webdriver.driver","chromedriver");
		 dr=new ChromeDriver();
		 dr.get("https://www.saucedemo.com/");
		 jobj=new login_ng(dr);
	 }
		 
	  
	@Test
	  public void t1()
	{
		  jobj.login("standard_user","secret_sauce");
		  
  
}
}
