package Test_ng;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testngexcelread {
	public static String[][] testdata=new String[2][3];
	public static int  r,c;


	public static void  getexcel()
	{

	System.out.println("In getexcell");
	String filename="C:\\Users\\BLTuser.BLT0192\\Downloads\\re\\loginexcel.xlsx";
	String   Sheet="Sheet1";
	int r=1;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	for( r=0;r<=1;r++ )
	{
	XSSFRow row=sh.getRow(r);
	for(c=0;c<=2;c++)
	{
	// XSSFRow row=sh.getRow(r);
	XSSFCell cell1 =row.getCell(c);
	testdata[r][c] =cell1.getStringCellValue();
//	// System.out.println(testdata[r][c]);
//	XSSFCell cell2 =row.getCell(c);
//	testdata[r][c] =cell2.getStringCellValue();
//	//System.out.println(testdata[r][c]);
//	XSSFCell cell3 =row.getCell(c);
//	testdata[r][c] =cell3.getStringCellValue();
//	System.out.println(testdata[r][c]);

	}


	}

	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}

	String s1;
	 public String logindemo(String Username,String  Password)
	{

	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");   ///span[@for='Email']
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();
	dr.findElement(By.xpath("//input[@class='email']")).sendKeys(Username);
	dr.findElement(By.xpath("//input[@class='password']")).sendKeys(Password);
	dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	s1=dr.findElement(By.xpath("//a[@class='account']")).getText();
	return s1;
	}

	}


