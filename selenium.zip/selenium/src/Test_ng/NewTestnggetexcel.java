package Test_ng;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTestnggetexcel  extends Testngexcelread{

@BeforeClass
 public void beforeClass() {

getexcel();
 }


@Test(dataProvider = "dp")
 public void login(String Username, String Password,String E_results)
 {
//  l=new demowebloginDATAPR();
String A_results=logindemo(Username,Password);
System.out.println(A_results);
SoftAssert sa=new SoftAssert();
sa.assertEquals(A_results, E_results);
sa.assertAll();
 }
 @DataProvider(name="dp")
 public String[][] provider()
 {
 
return testdata;
 
}
 





 // @Test
  public void f() {
  }
}
