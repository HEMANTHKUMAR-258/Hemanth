package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class whalewatch {
	WebDriver dr;
 	boolean b;
	
	public whalewatch(WebDriver dr)
	{
	this.dr=dr;
	}
	public void  presenceofwhalewatching() {
		 String s=dr.findElement(By.xpath("//a[@href='/alaska-whale-watching-and-wildlife']")).getText();//Getting text on the link page
		 System.out.println(s);
		  b=dr.findElement(By.xpath("//a[@href='/alaska-whale-watching-and-wildlife']")).isDisplayed();
		 System.out.println(b);
		
	}
	public void clckShip() throws InterruptedException {
				Thread.sleep(2000);
		
		 dr.findElement(By.xpath("//a[@href='/cruise-ships']")).click();
		
	}
	
	public void total_whale() throws InterruptedException {
		this.presenceofwhalewatching();
		this.clckShip();
	
	}
	
}
