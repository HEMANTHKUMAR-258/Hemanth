package TestCase;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BASECLASS.Library;
import PAGES.deck;
import PAGES.rhodassea;
import PAGES.royal;
import PAGES.whalewatch;

public class Royaltestng1 extends Library {
	WebDriver dr;
	String s1;
	boolean b=true;
	@BeforeClass
	public void launch() {
		dr=launchBrowser("Firefox","http://royalcaribbean.com/alaska-cruises");
	}
	@Test
	 public void page1() throws InterruptedException {
		  
		  whalewatch w1=new whalewatch(dr);//Object Creating
		  w1.total_whale();//calling through object
		  
		  
	  }
	@Test(priority=1)
	public void page2() throws InterruptedException {
		  
		  rhodassea w12=new rhodassea(dr);//object creating
		  w12.seatchrhodas();//calling through object
		  
		  
	  }
	  @Test(priority=2)
	  public void page3() throws InterruptedException {
		  
		  deck w12=new deck(dr);//object Creating
		  w12.clkdeck();//Calling with Object
		  
		    
	  }
	  @Test(priority=3)
	  public void page4() throws InterruptedException {
		  
		  royal w12=new royal(dr);//Object Creating
		 s1= w12.deckselect();//Calling with Object
		 System.out.println(s1);
		 if(s1.contains("Royal")&&b)
			{
				boolean b1=true;
				System.out.println("meet the requirement");
				Assert.assertTrue(b1, "meet the requirement");
			}
			else
			{
				boolean b1=false;
				Assert.assertTrue(b1, "don't meet requirement");
			}
		    
	  }
	  @AfterClass
	  public void Ac() {
		  dr.close();
	  }
 
}
