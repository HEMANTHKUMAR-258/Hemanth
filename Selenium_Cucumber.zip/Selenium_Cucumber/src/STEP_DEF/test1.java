package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	String a_title;
	String e_title="Demo Web Shop";
    String e_email="tirumalashetty.harika@gmail.com";
	String test_result;

@Given("^Browser is launched & login page displayed$")
public void browser_is_launched_login_page_displayed() throws Throwable {
	System.out.println("Browser is launched & login page displayed");
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/login");
	
}
    


@When("^User enters login credentials &clicks on login$")
public void user_enters_login_credentials_clicks_on_login() throws Throwable {
	System.out.println("^User enters login credentials &clicks on login$");
	dr.findElement(By.xpath("//input[@id='Email']")).sendKeys("tirumalashetty.harika@gmail.com");
	dr.findElement(By.xpath("//input[@class='password']")).sendKeys("anjaneya9$");
	dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	
}
 

@Then("^Successful login happens & Profile name displayed correctly$")
public void successful_login_happens_Profile_name_displayed_correctly() throws Throwable {
   System.out.println("^Successful login happens & Profile name displayed correctly$");
   a_title= dr.getTitle();
  String a_email= dr.findElement(By.xpath("//div[@class='header-links']//child::a[1]")).getText();
   if(a_title.equals(e_title) && a_email.equals(e_email))
   {
	   test_result="pass";
   }
   else 
   {
	   test_result="fail";
   }
System.out.println("test_result:" +test_result);   

}
}
