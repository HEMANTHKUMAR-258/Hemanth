package DAY5;

public class Icici extends bank{
     float get_roi(){
    	 return 8.6f;
     }
}
