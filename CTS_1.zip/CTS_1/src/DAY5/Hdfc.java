package DAY5;

public class Hdfc extends bank {
	 float get_roi(){
		
	
	return 9.5f;
	}
}
