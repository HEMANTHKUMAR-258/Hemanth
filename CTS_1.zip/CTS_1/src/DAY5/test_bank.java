package DAY5;

public class test_bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        bank b;
        b =new Icici();
        System.out.println("Icici ROI: "  +b.get_roi());
        b=new Hdfc();
        System.out.println("Hdfc ROI: " +b.get_roi());
	}

}
