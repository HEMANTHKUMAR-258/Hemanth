package DAY5;
import java.util.ArrayList;

public class ArrayList_Demo {
	ArrayList<Student> std_a= new ArrayList<Student>();
      
	public void create_al(){
		Student s1=new Student("rames",80,90,88);
		Student s2=new Student("suresh",90,70,90);
		std_a.add(s1);
		std_a.add(s2);
	}
	
	public void display(){
		for(Student s: std_a){
		System.out.println("name:" +s.name 
				           + "java:" +s.java 
				           +"selenium:"+s.selenium 
				           +"avg" + s.avg);
		
	}
	}
	public static void main(String[] args){
		ArrayList_Demo a1=new ArrayList_Demo();
		a1.create_al();
		a1.display();
}
}
