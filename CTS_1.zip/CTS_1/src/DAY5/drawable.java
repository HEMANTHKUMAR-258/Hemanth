package DAY5;

public interface drawable {
	
	void draw();

}
