package DAY5;
import java.util.ArrayList;

public class Arraylist_ {

	public static void main(String[] args) {
    		// TODO Auto-generated method stub
      ArrayList<String> str_a= new ArrayList<String>();
      
      
      str_a.add("ramesh");
      str_a.add("hemanth");
      str_a.add("harika");
     
      System.out.println("BEFORE INSERTION :" +str_a );
      
      str_a.add(2,"harsha");
      
      System.out.println("AFTER INSERTION : " +str_a);
      
      str_a.remove(0);
      System.out.println("AFTER DELETION:" +str_a);
      
      for (String s: str_a){
    	  System.out.println(s);
      }
       
      str_a.add(3,"HLoo");
      
	}

}
