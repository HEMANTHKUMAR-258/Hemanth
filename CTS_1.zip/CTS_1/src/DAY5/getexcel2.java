package DAY5;

public class getexcel2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        getexcel e=new getexcel();
        e.readdata("C:\\Users\\BLTuser.BLT0192\\Desktop\\he")
	}

}
