package DAY5;

import java.io.FileOutputStream;
import java.io.FilterOutputStream;

public class text_wr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileOutputStream fos= new FileOutputStream("C:\\Users\\BLTuser.BLT0192\\Desktop\\note\\iam.txt");
		}

	}

}
