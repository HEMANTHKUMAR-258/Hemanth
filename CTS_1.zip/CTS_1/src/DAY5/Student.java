package DAY5;

public class Student {
      
	int id;
	String name;
	int selenium;
	int java;
	float avg;
	
	public Student(String name,int id, int selenium,int java){
		System.out.println("object created");
		this.java=java;
		this.selenium=selenium;
		this.id=id;
		this.avg=avg;
		this.name=name;
	}
	
	
	public void calc_avg(){
		avg=((selenium+java)/2.0f);
	}
}