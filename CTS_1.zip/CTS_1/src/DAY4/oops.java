package DAY4;

public class oops {
	 public int add (int x,int y){
  	   int z=x+y;
  	   System.out.println("2parms");
  	   return z;
	 }
	 public int add(int a,int b,int c){
		 int d=a+b+c;
		 System.out.println("3parms");
		 return d;
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      oops o= new oops();
      int m=o.add(2,3);
      int m1=o.add(2,3,4);
      System.out.println(m);
      System.out.println(m1);
       }
	}


