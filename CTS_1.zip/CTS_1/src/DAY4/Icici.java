package DAY4;

public class Icici extends bank{
     public float get_roi(){
    	 return 8.6f;
     }
}
