package DAY4;

public class Hdfc extends bank {
	public float get_roi(){
		
	
	return 9.5f;
	}
}
