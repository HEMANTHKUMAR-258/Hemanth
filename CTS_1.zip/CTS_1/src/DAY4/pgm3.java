package DAY4;

public class pgm3 {
	int z;
	 static String [][] sid={{"1","hemanth"},{"2","ravi"},{"3","kumar"},{"4","devaki"}};
	 static int [][] marks   ={{1,80,90,0},{2,90,70,0},{3,78,89,0},{4,77,88,0}};
	   
	  public int search(String sid){
		  int index=0,i;
		  int id=Integer.parseInt(sid);
		    for(i=0;i<=4;i++){
	            
		    	if(id==marks[i][0])
		    	{index=i;
		    	break;
		    	}
		    	  return index;
		    }
		  
	  }
	 
	 
}
