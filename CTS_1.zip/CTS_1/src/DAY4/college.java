package DAY4;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i;
        float f;
        
        Student ramesh =new Student(80,90);
        /*ramesh.selenium=90;
        ramesh.java=80;*/
        ramesh.calc_avg();
        System.out.println(ramesh.avg);
        Student hemanth=new Student(70,80);
        hemanth.calc_avg();
        System.out.println(hemanth.avg);
	}

}
