package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r,c,i,largest;
		int [] a={18,4,-2,29};
		int lar =a[0];
		for(i=1;i<a.length;i++){
		
			if(a[i]>lar){
				lar=a[i];
			}
				
		
			}
		System.out.println(lar);
		}
      
	}


