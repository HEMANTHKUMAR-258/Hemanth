package DAY2;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am learning core java";
		int i=0,p=0,c=0;
		
		
		while(p>=0){
			p=s.indexOf(" ",i);
			c++;
			i=p+1;
			c=c-1;
		}
System.out.println(c);

	}
  

}

