package DAY2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c;
		int [] m={1,3,5,6,8,9};
		try{
			System.out.println("before");
		c=a/b;
		System.out.println("after");
		}
		catch(Exception e){
			System.out.println("in");
		}
		System.out.println(m[7]);

	}

}
