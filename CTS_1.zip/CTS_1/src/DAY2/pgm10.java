package DAY2;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[][]={{18,4,-2,29},{8,99,3,9}};
int i,j;
int max=a[0][0];
for(i=0;i<a.length;i++)
{
	for(j=0;j<a.length;j++)
	{
		if(a[i][j]>max)
			max=a[i][j];
	}
	System.out.println(max);
}
	}

}
