package DAY2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am learning core java";
		int i=0,p=0,c=0;
		String s1;
		
		while(p>=0){
			p=s.indexOf(" ",i);
			c++;
			if(p==-1){
			p=s.length();	
			}
			
			s1=s.substring(i,p);
			System.out.println(s1);
			System.out.println("i ='"+i+"p="+p);
			i=p+1;
		}
		


	}
  

	}


