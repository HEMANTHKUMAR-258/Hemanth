package DAY2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] [] marks= {{77,88,99},{66,55,44}};
		int r,c,sum=0;
		for(r=0;r<=1;r++){
			for(c=0;c<=2;c++){
				if(marks[r][c]%2==0)
					sum=sum+marks[r][c];
					
			}
		}
  System.out.println(sum);
	}

}
