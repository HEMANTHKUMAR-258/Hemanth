package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=2,c;
		int [] m={1,2,4,5,6};
        try{
        	c=a/b;
        	System.out.println(m[7]);
        }
        catch(ArithmeticException ae){
        	System.out.println("catch Arithmetic Exception");
        	
        }
        catch(  ArrayIndexOutOfBoundsException aie){
        	System.out.println("catch ArrayIndexOutOfBoundsException");
        }
	}
	

}
