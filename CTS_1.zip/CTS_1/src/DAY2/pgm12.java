package DAY2;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int[][] m={ {11,25,54,65},{54,62,24,32},{26,24,56,34}};
  int[][] s={ {54,62,24,32},{44,25,34,85},{26,24,56,34}};
  int[][] p= new int [3][4];
  for(int i=0;i<2;i++){
	  for(int j=0;j<3;j++){
		  p[i][j]=m[i][j]+s[i][j];
		  System.out.println(p[i][j]+" ");
	  }
	  System.out.println(" ");
  }
	}
}


