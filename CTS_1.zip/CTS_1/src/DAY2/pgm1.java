package DAY2;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int[] marks={60,57,81,59,48,57,68,98};
         int sum=0,i;
        		 float avg;
         for(i=0;i<7;i++){
         sum=sum+marks[i];
        
       
       }
         avg=sum/8;
         System.out.println(avg);
         if(avg>=70){
        	 System.out.println("first class with dis" );
         }
         else if(avg >=60 && avg<70)
        	 System.out.println("First class");
         if(avg >=50 && avg <60){
        	 System.out.println("second class");
         }
	}
	
     

}
