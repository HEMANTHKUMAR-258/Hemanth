package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "chennai",s1="Chennai",s2="chennai",s3;
		int l=s.length();
		int v =s.compareTo(s1);
		 System.out.println("length = "+ l + "return value: " +v);
   int rv =s.compareToIgnoreCase(s1);
   System.out.println("rv=" + rv);
   
   s3=s.substring(0,4);
   System.out.println("substring:" +s3);
   
	}

}