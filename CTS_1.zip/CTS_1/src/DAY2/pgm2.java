package DAY2;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] marks={90,98,88,78,68,77};
		int i,sum=0;
		
		for(i=0;i<=5;i=i+2){
			if(marks[i]%2==1)
			sum=sum+marks[i];
			
		}
         System.out.println(sum);
	}

}
