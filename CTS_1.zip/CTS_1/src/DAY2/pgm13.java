package DAY2;

public class pgm13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="hello,how are you?";
		int count=0;
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)=='o');
			count++;
		}
  System.out.println(count);
	}

}
