package DAY2;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  i,j,length;
    int [] m ={21,34,91,59,16,44,29,74,49,82};
    for( i=0;i<m.length;i++){
    	for( j=1;j<m.length-1;j++){
    		if(m[i]+m[j]==65){
                 System.out.println("the sum of"+ m[i]+"&"+m[j] + "is 65");   			
    		}
    	}
    }


}
}