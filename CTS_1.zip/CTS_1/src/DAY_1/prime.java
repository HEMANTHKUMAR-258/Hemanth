package DAY_1;

public class prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,c=0;
		for(i=2;i<10;i++,c=0){
			for(j=2;j<=i/2;j++)
				if[i%j==0]
						c++;
			
		}

	}

}
