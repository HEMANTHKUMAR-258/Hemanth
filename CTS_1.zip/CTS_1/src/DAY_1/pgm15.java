package DAY_1;

public class pgm15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=0,i=1,j,c=0,s=0;
        while(n<10) {
            j = 1;
            c = 0;
            while (j <= i) {
                if (i % j == 0) {
                    c++;
                }
                j++;
            }
            if (c == 2) {
               
                n++;
                System.out.println(i);
                if(n>5)
                {
                    s=s+i;
                }
               
            i++;
        }
        System.out.println(s);




        }
	}
}


