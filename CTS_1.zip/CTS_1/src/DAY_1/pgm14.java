package DAY_1;

public class pgm14 {

	public static void main(String[] args) {
 		// TODO Auto-generated method stub
         
		int num=725,temp,digit,count=0;
		temp=num;
		while(num>0)
		{
		num=num/10;
		count++;
		}
		while(temp>0)
		{
		digit=temp%10;
		System.out.println(digit);
		temp=temp/10;
		count--;
		}
 	}

}
