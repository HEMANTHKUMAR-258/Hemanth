package DAY_1;

import javafx.util.converter.PercentageStringConverter;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      long salary=750000,t,s1,t1,t2;
      if(salary>=500000 && salary<=800000)
      {
    	  s1=salary-500000;
          t=s1*(10.0f/100.0f);
          t1=(500000-180000)*(10/100);
          t2=t+t1;
    	  System.out.println(t2);
      }
       
    	  
    	 
      
	}

}
