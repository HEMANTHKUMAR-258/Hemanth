package DAY_1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5,j=4,k,s;
		for( k=1;k<=5;k++){
			s=i*j;
			System.out.println(i+" *"+j+"="+s);
			i=i+1;
			j=j+2;
		}

	}

}
