package DAY_1;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,c=0;
		for(i=17;i<=75;i++)
		{
		if((i%17==0))
		{
		System.out.println(i);
		c++;
		}
		}
		}

	}


