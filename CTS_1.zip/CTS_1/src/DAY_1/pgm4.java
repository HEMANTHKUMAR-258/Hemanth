package DAY_1;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=15,b=10,c=4;
        if(a<b)
        {
        	if(a<c)
        	System.out.println(a+ "is small number" );
        }
        else if(b<c)
        	System.out.println(b+ "is small number");
        else
        	System.out.println(c+ "is small number");
	}

}
