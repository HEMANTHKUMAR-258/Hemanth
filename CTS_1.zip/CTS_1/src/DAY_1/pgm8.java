package DAY_1;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rem,sum=0,n=1234;
		while(n>0){
			
			rem=n%10;
			sum=sum+rem;
			n=n/10;
		}
		System.out.println(sum);

	}

}
