package DAY_1;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int i=5489,sum=0,rem;
   while(i>0){
	   rem =i%10;
	   if (rem>5){
		   sum=sum+rem;
		   
	   }
        i=i/10;   
   }
   
   System.out.println(sum);
	}

}
