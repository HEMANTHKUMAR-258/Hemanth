package DAY3;

public class calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		derivedcal d=new derivedcal();
		d.mul();
		d.add();
		d.sub();

	}

}
