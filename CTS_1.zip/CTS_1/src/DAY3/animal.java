package DAY3;

public class animal {
	 int age,weight,height;
	 char gender;
	 String colour;
	  
	 public void display()
	 {
		 System.out.println("age : " + age + " weight: " + weight +"height :"+ height + "gender :"+gender);
	 }
	 

}
