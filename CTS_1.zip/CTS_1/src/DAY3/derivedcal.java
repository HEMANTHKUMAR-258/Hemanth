package DAY3;

public class derivedcal extends class_calc{
	public void mul()
	{
		
		num=num1*num2;
		System.out.println(num);
	}
	}


