package DAY3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i;
        float f;
        
        Student ramesh =new Student();
        ramesh.selenium=90;
        ramesh.java=80;
        ramesh.calc_avg();
        System.out.println(ramesh.avg);
	}

}
