package DAY3;
import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,c=1;
    String emp [][] ={{"e1","hemanth"},{"e2","ravi"},{"e3","kumar"},{"e4","devaki"},{"e5","pavan"}};
    System.out.println("enter emp id");
    Scanner sc=new Scanner(System.in);
    String emp_id=sc.nextLine();
    
    for(i=0;i<=4;i++){
    	for(j=0;j<1;j++){
    		
    		c=emp_id.compareTo(emp[i][j]);
    		if(c==0){
    			System.out.println(emp[i][j+1]);
    			break;
    		}
    	}
    }
	}

}
