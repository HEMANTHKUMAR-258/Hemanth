package DAY3;

public class elephant extends animal {
	int lotrunk,lotusk;
	public void display_detials(){
		
		super.display();
		System.out.println("lotrunk: "+ lotrunk + "lotusk: "+ lotusk);
	}

}
