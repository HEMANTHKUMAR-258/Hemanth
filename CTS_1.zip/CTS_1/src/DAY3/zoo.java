package DAY3;

public class zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
		elephant e1=new elephant();
		e1.age=8;
		e1.gender='m';
		
		e1.weight=200;
		e1.height=8;
		e1.lotrunk=2;
		e1.lotusk=1;
		e1.display_detials();
		
		
		
	}

}
