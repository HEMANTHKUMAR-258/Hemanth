package DAY3;
import java.util.Scanner;
public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
	System.out.println("enter a string: ");
	Scanner input=new Scanner(System.in);
	char s = input.next().charAt(0);
	while(s!='n')
	{
		
		if(s=='a'||s=='e'||s=='i'||s=='o'||s=='u'){
			
			count++;
			
		}
		 s = input.next().charAt(0);
	}
	System.out.println(count);

	}

}
