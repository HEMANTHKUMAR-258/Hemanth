package DAY3;

public class library {
   
	 public int add(int x,int y){
		 int z=x+y;
		// System.out.println(z);
		 return z;
		
	 }
	 public int power(int x,int y)
	 {
		 int  pow=-1;
		 for(int i=1;i<=y;i++)
		 {
			 pow=pow*x;
		 }
		 return pow;
	 }
}
