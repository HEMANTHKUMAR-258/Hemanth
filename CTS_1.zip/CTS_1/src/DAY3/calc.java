package DAY3;

public class calc extends library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		//calling function
		calc c= new calc();
		int d=c.add(3,5);
		System.out.println("addition: "+d);
	}

}
